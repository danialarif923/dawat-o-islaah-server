from django.shortcuts import render

from .models import Ayat
from django.http import JsonResponse

def get_ayat(request):
    para = request.GET.get("para")
    surah = request.GET.get("surah")
    ayat = request.GET.get("ayat")

    try:
        obj = Ayat.objects.get(
            para=para,
            surah=surah,
            ayat_number=ayat
        )
        return JsonResponse({"text": obj.text})
    except Ayat.DoesNotExist:
        return JsonResponse({"text": ""})