from django.contrib import admin
from .models import Ayat

@admin.register(Ayat)
class AyatAdmin(admin.ModelAdmin):

    list_display = ("para", "surah", "ayat_number", "created_at")
    list_filter = ("para", "surah")
    search_fields = ("text",)

    def has_add_permission(self, request):
        return True

    def has_change_permission(self, request, obj=None):
        # superuser can always edit
        if request.user.is_superuser:
            return True
        # allow staff to edit
        if request.user.is_staff:
            return True
        return False

    
    def save_model(self, request, obj, form, change):
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)

    class Media:
        js = (
            "js/quran_data.js",   # FIRST
            "js/ayat_admin.js",   # SECOND
        )
# Register your models here.
