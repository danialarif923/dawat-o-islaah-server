from django.urls import path
from .views import get_ayat

urlpatterns = [
    path("get-ayat/", get_ayat, name="get-ayat"),
]
