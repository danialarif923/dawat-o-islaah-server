from django.db import models
from django.conf import settings

# Create your models here.
class Ayat(models.Model):

    PARA_CHOICES = [(i, f"Para {i}") for i in range(1, 31)]

    para = models.IntegerField(choices=PARA_CHOICES)

    surah = models.IntegerField()

    ayat_number = models.IntegerField()

    text = models.TextField()

    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    class Meta:
        unique_together = ("para", "surah", "ayat_number")

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Para {self.para} | Surah {self.surah} | Ayat {self.ayat_number}"